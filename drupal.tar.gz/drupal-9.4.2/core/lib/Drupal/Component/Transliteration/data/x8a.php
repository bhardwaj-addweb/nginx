<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'yan', 'yan', 'ding', 'fu', 'qiu', 'qiu', 'jiao', 'hong', 'ji', 'fan', 'xun', 'diao', 'hong', 'chai', 'tao', 'xu',
  0x10 => 'jie', 'yi', 'ren', 'xun', 'yin', 'shan', 'qi', 'tuo', 'ji', 'xun', 'yin', 'e', 'fen', 'ya', 'yao', 'song',
  0x20 => 'shen', 'yin', 'xin', 'jue', 'xiao', 'ne', 'chen', 'you', 'zhi', 'xiong', 'fang', 'xin', 'chao', 'she', 'xian', 'sa',
  0x30 => 'zhun', 'xu', 'yi', 'yi', 'su', 'chi', 'he', 'shen', 'he', 'xu', 'zhen', 'zhu', 'zheng', 'gou', 'zi', 'zi',
  0x40 => 'zhan', 'gu', 'fu', 'jian', 'die', 'ling', 'di', 'yang', 'li', 'nao', 'pan', 'zhou', 'gan', 'yi', 'ju', 'yao',
  0x50 => 'zha', 'yi', 'yi', 'qu', 'zhao', 'ping', 'bi', 'xiong', 'qu', 'ba', 'da', 'zu', 'tao', 'zhu', 'ci', 'zhe',
  0x60 => 'yong', 'xu', 'xun', 'yi', 'huang', 'he', 'shi', 'cha', 'xiao', 'shi', 'hen', 'cha', 'gou', 'gui', 'quan', 'hui',
  0x70 => 'jie', 'hua', 'gai', 'xiang', 'wei', 'shen', 'zhou', 'tong', 'mi', 'zhan', 'ming', 'e', 'hui', 'yan', 'xiong', 'gua',
  0x80 => 'er', 'bing', 'tiao', 'yi', 'lei', 'zhu', 'kuang', 'kua', 'wu', 'yu', 'teng', 'ji', 'zhi', 'ren', 'cu', 'lang',
  0x90 => 'e', 'kuang', 'ei', 'shi', 'ting', 'dan', 'bei', 'chan', 'you', 'keng', 'qiao', 'qin', 'shua', 'an', 'yu', 'xiao',
  0xA0 => 'cheng', 'jie', 'xian', 'wu', 'wu', 'gao', 'song', 'bu', 'hui', 'jing', 'shuo', 'zhen', 'shuo', 'du', 'hua', 'chang',
  0xB0 => 'shui', 'jie', 'ke', 'qu', 'cong', 'xiao', 'sui', 'wang', 'xian', 'fei', 'chi', 'ta', 'yi', 'ni', 'yin', 'diao',
  0xC0 => 'pi', 'zhuo', 'chan', 'chen', 'zhun', 'ji', 'qi', 'tan', 'zhui', 'wei', 'ju', 'qing', 'dong', 'zheng', 'ze', 'zou',
  0xD0 => 'qian', 'zhuo', 'liang', 'jian', 'chu', 'hao', 'lun', 'shen', 'biao', 'huai', 'pian', 'yu', 'die', 'xu', 'pian', 'shi',
  0xE0 => 'xuan', 'shi', 'hun', 'hua', 'e', 'zhong', 'di', 'xie', 'fu', 'pu', 'ting', 'jian', 'qi', 'yu', 'zi', 'zhuan',
  0xF0 => 'xi', 'hui', 'yin', 'an', 'xian', 'nan', 'chen', 'feng', 'zhu', 'yang', 'yan', 'huang', 'xuan', 'ge', 'nuo', 'qi',
];
