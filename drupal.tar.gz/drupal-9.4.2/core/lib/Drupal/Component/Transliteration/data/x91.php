<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'ruo', 'bei', 'e', 'shu', 'juan', 'yu', 'yun', 'hou', 'kui', 'xiang', 'xiang', 'sou', 'tang', 'ming', 'xi', 'ru',
  0x10 => 'chu', 'zi', 'zou', 'ye', 'wu', 'xiang', 'yun', 'hao', 'yong', 'bi', 'mao', 'chao', 'fu', 'liao', 'yin', 'zhuan',
  0x20 => 'hu', 'qiao', 'yan', 'zhang', 'man', 'qiao', 'xu', 'deng', 'bi', 'xun', 'bi', 'zeng', 'wei', 'zheng', 'mao', 'shan',
  0x30 => 'lin', 'po', 'dan', 'meng', 'ye', 'cao', 'kuai', 'feng', 'meng', 'zou', 'kuang', 'lian', 'zan', 'chan', 'you', 'ji',
  0x40 => 'yan', 'chan', 'cuo', 'ling', 'huan', 'xi', 'feng', 'zan', 'li', 'you', 'ding', 'qiu', 'zhuo', 'pei', 'zhou', 'yi',
  0x50 => 'gan', 'yu', 'jiu', 'yan', 'zui', 'mao', 'zhen', 'xu', 'dou', 'zhen', 'fen', 'yuan', 'fu', 'yun', 'tai', 'tian',
  0x60 => 'qia', 'tuo', 'cu', 'han', 'gu', 'su', 'fa', 'chou', 'zai', 'ming', 'lao', 'chuo', 'chou', 'you', 'tong', 'zhi',
  0x70 => 'xian', 'jiang', 'cheng', 'yin', 'tu', 'jiao', 'mei', 'ku', 'suan', 'lei', 'pu', 'zui', 'hai', 'yan', 'shai', 'niang',
  0x80 => 'wei', 'lu', 'lan', 'yan', 'tao', 'pei', 'zhan', 'chun', 'tan', 'zui', 'zhui', 'cu', 'kun', 'ti', 'xian', 'du',
  0x90 => 'hu', 'xu', 'xing', 'tan', 'qiu', 'chun', 'yun', 'po', 'ke', 'sou', 'mi', 'quan', 'chou', 'cuo', 'yun', 'yong',
  0xA0 => 'ang', 'zha', 'hai', 'tang', 'jiang', 'piao', 'chen', 'yu', 'li', 'zao', 'lao', 'yi', 'jiang', 'bu', 'jiao', 'xi',
  0xB0 => 'tan', 'fa', 'nong', 'yi', 'li', 'ju', 'yan', 'yi', 'niang', 'ru', 'xun', 'chou', 'yan', 'ling', 'mi', 'mi',
  0xC0 => 'niang', 'xin', 'jiao', 'shai', 'mi', 'yan', 'bian', 'cai', 'shi', 'you', 'shi', 'shi', 'li', 'zhong', 'ye', 'liang',
  0xD0 => 'li', 'jin', 'jin', 'qiu', 'yi', 'liao', 'dao', 'zhao', 'ding', 'po', 'qiu', 'ba', 'fu', 'zhen', 'zhi', 'ba',
  0xE0 => 'luan', 'fu', 'nai', 'diao', 'shan', 'qiao', 'kou', 'chuan', 'zi', 'fan', 'hua', 'hua', 'han', 'gang', 'qi', 'mang',
  0xF0 => 'ri', 'di', 'si', 'xi', 'yi', 'chai', 'shi', 'tu', 'xi', 'nu', 'qian', 'qiu', 'jian', 'pi', 'ye', 'jin',
];
